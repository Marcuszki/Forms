<?php
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $nome = htmlspecialchars($_POST['nome']);
    $email = htmlspecialchars($_POST['email']);
    $assunto = htmlspecialchars($_POST['assunto']);
    $mensagem = htmlspecialchars($_POST['mensagem']);

    echo"<h1>Formulario enviado com Sucesso.</h1>";
    echo"<p>Nome: $nome</p>";
    echo"<p>E-mail: $email</p>";
    echo"<p>Assunto: $assunto</p>";
    echo"<p>Mensagem: $mensagem</p>";

    }else{
        echo"<h1>Formulario não enviado.</h1>";
        
    }
?>