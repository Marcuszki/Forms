<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title> Registro de Eventos</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1> Registro de Eventos</h1>
    <form id="formulario" action="Forms2ATV7.php" method="POST">
            <label for="Usuario">Insira o nome dos participante:</label><br>
            <input type="text"  name="participantes[0][nome]" required minlength="3" maxlength="50"> <br>
            <label for="email"> Digite o email do participante :</label><br>
            <input type="text" name="participantes[0][email]"> <br>
            <label for="Eventos">Eventos de interesse:</label><br>
            <select id="eventos" name="participantes[0][eventos]" required>
                <option value="">Selecione...</option>
                <option value="happy hours">happy hours</option>
                <option value="Festas ao ar livre">Festas ao ar livre</option>
                <option value="Open House">Open House</option>
            </select>
            <br>


            <label for="Usuario">Insira o nome dos participante:</label><br>
            <input type="text" name="participantes[1][nome]" required minlength="3" maxlength="50"> <br>
            <label for="email"> Digite o email do participante :</label><br>
            <input type="text" name="participantes[1][email]"> <br>
            <label for="Eventos">Eventos de interesse:</label><br>
            <select id="eventos" name="participantes[1][eventos]" required>
                <option value="">Selecione...</option>
                <option value="happy hours">happy hours</option>
                <option value="Festas ao ar livre">Festas ao ar livre</option>
                <option value="Open House">Open House</option>
            </select>
            <br>
            <button type="submit">Enviar</button>
        </form>

    <div id="resultado"></div>

<script>
    $(document).ready(function() {
        $('#formulario').submit(function(event){
            event.preventDefault();

            var participantes = [];
            $('input[name="participantes[]"]').each(function() {
                participantes.push(this.value);
            });

            $.ajax({
                type: 'POST',
                url: 'Forms2ATV7.php',
                data: {
                    participantes: participantes,
                },
                success: function(response){
                    
                    $('#resultado').html(''+ response);
                   
                },
                error: function(xhr, status, error){
                    $('#resultado').html('Erro: ' + error);
              
                }

            });
        });
    });
</script>

</body>
</html>