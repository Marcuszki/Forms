<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $participantes = $_POST['participantes'];
    var_dump($participantes);
    exit();

   // print_r($participantes);
   // exit();

   $string = '';
    foreach($participantes as $chave=>$p){
   
        
        $string.="<h3>Nome do participante </h3>  ".$participantes[$chave]['nome'].'<br>';

        $string.="<h3>E-mail do participante </h3>  ".$participantes[$chave]['email'].'<br>';

        $string.="<h3>Evento de interesse do participante </h3>  ".$participantes[$chave]['eventos'].'<br><br>';
    }
    echo $string;


}
?>