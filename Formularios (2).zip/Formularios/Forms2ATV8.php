<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
}

echo" <h2>inscrição realizada com sucesso.</h2> ";
?>