<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = htmlspecialchars($_POST['user']);
    $product = htmlspecialchars($_POST['product']);
    $av = htmlspecialchars($_POST['av']);
    $coments = htmlspecialchars($_POST['coments']);
    $imagem = $_FILES['imagem']['tmp_name'];

    echo"<h3>Usuario:</h3>";
    echo"$user<br>";
    echo"<h3>Produto:</h3>";
    echo"$product<br>";
    echo"<h3>Avaliação:</h3>";
    echo"$av<br>";
    echo"<h3>Comentarios:</h3>";
    echo"$coments<br>";     

    $aExtraInfo = getimagesize($imagem);
    $sImage = "data:" . $aExtraInfo["mime"] . ";base64," . base64_encode(file_get_contents($imagem));
    echo '<h1>Imagem do produto:</h1><br><p>Preview:</p><img src="' . $sImage . '" />';
} 
?>