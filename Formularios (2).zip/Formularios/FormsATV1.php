<!DOCTYPE html>
<html lang="PT-BR">
<head>
    <meta charset="UTF-8">
    <title>Formulário de Cadastro Simples</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>



<Body>
<form id='formulario-Cadastro' name="Cadastro" action="Forms2ATV1.php" method="POST">
        <h1>Realizar Cadastro</h1>
        <br>
        <br>
        <label for="Nome">Nome:</label><br>
        <input type="text" id="nome" name="nome" required minlength="3" maxlength="50" placeholder="Digite seu Nome "> <br>

        <label for="email">E-mail:</label><br>
        <input type="email" id="email" name="email" placeholder="Digite seu e-mail"> <br>

        <label for="Senha">Senha:</label><br>
        <input type="password" id="Senha" name="Senha"  size="8"> <br>

        <label for="confirmar_senha">Confirmar Senha:</label><br>
        <input type="password" id="confirmar_senha" name="confirmar_senha"  size="8"> <br>

        <label for="data_nascimento">Data de Nascimento:</label><br>
        <input type="date" id="data_nascimento" name="data_nascimento" required><br>

        <label for="Gênero">Gênero: </label><br>
        <select id="Gênero" name="Gênero" required>
            <option value="">Selecione...</option>
            <option value="Masculino">Masculino</option>
            <option value="Feminino">Feminino</option>
            <option value="Outro">Outro</option>
        </select>
        <br>   
        <br>
        <input type="submit" value="Enviar">
</form>
<div id="resultado"></div>

<script>
    $(document).ready(function() {
        $('#formulario-Cadastro').submit(function(event){
            event.preventDefault();

            var nome = $('#nome').val();
            var email = $('#email').val();

            $.ajax({
                type: 'POST',
                url: 'Forms2ATV1.php',
                data: {
                    nome: nome,
                    email: email,
                },
                success: function(response){
                    
                    $('#resultado').html(''+ response);
                   
                },
                error: function(xhr, status, error){
                    $('#resultado').html('Erro: ' + error);
              
                }

            });
        });
    });
</script>
</Body>        
</html>