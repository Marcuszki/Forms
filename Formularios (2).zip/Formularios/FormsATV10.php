<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Enquete de Preferências</title>
</head>
<body>
    <h1>Enquete de Preferências</h1>
    <form action="Forms2ATV10.php" method="POST">
           
    <label for="Filmes">Filmes:</label><br>
    <input type="checkbox" id="duna2" name="duna2" value="duna2">
    <label for="duna2">Duna 2</label><br>
    <input type="checkbox" id="lobodewallstreet" name="lobodewallstreet" value="lobodewallstreet">
    <label for="lobodewallstreet">lobo de wall street</label><br>
        
    <button type="submit">Enviar</button>
    </form>
</body>
</html>