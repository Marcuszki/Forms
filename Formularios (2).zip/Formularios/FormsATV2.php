<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Formulário POST</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<form id='formulario-login'action="Forms2ATV2.php" method="post">
        <h1>Realizar Login</h1>
        <br>
        <br>
       <label for="email">Insira seu Usuario:</label><br>
       <input type="user" id="user" name="user" placeholder="Insira seu nome de usuario cadastrado:"> <br>

       <label for="Senha">Insira sua Senha:</label><br>
       <input type="password" id="senha" name="senha" ><br>
       <br>
       <input  type="submit" value="Fazer Login">
    
    </form>

    <div id="resultado"></div>

<script>
    $(document).ready(function() {
        $('#formulario-login').submit(function(event){
            event.preventDefault();

            var user = $('#user').val();
            var senha = $('#senha').val();

            $.ajax({
                type: 'POST',
                url: 'Forms2ATV2.php',
                data: {
                    user: user,
                    senha: senha,
                },
                success: function(response){
                    
                    $('#resultado').html(''+ response);
                   
                },
                error: function(xhr, status, error){
                    $('#resultado').html('Erro: ' + error);
              
                }

            });
        });
    });
</script>
</body>
</html>