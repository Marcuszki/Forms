 <?php


$repostasUsuarios = $_POST['quiz'];

$respostasCorretas = array('0'=>'Luffy',
                           '1'=>'GOKU',
                           '2'=>'7',
                           '3'=>'Lancer',
                           '4'=>'Cruzeiro',
                            );


    $iCorretos = 0;
    foreach($repostasUsuarios as $chave=>$valor){
        if($respostasCorretas[$chave]==$valor){
            $iCorretos++;
        }
    }

    echo "<h2>Sua pontuação e $iCorretos</h2>";
    if($iCorretos>=3){
        echo "<h3>Voce e um Genio!!!</h3>";
    }else{
        echo"<h3>Burro pra carai kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk</h3>";
    }

?>