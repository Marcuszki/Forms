<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Feedback de Produtos</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>
<body>
    <h1>Feedback de Produtos</h1>
    <form id="formulario" action="Forms2ATV6.php" method="POST" enctype="multipart/form-data">
            <label for="Usuario">Digite seu nome de Usuario:</label>
            <input type="text" id="user" name="user" required minlength="3" maxlength="50" placeholder="Digite seu Nome de Usuario "> <br>
            <br>
            <label for="Produto"> Digite o nome do produto:</label>
            <input type="text" id="product" name="product" placeholder="Digite seu Nome do produto "> <br>
            <br>
            <label for="Avaliação">Avaliação de (1 a 5 estrelas):</label>
            <select id="av" name="av" required>
                <option value="">Selecione...</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
            </select>
            <br>
            <label for="Comentario"> Digite um comentario sobre o produto:</label>
            <input type="text" id="coments" name="coments"> 
            <br><br>
            <label for="Imagem"> Insira uma foto do produto:</label>
            <input type="file" id="imagem" name="imagem"> 
            <br><br>
            <button type="submit">Enviar</button>
        </form>

<div id="resultado"></div>
<script>
    $(document).ready(function() {
        $('#formulario').submit(function(event){
            event.preventDefault();

            var user = $('#user').val();
            var product = $('#product').val();
            var av = $('#av').val();
            var coments = $('#coments').val();
            var imagem = $('#imagem').val();

            $.ajax({
                type: 'POST',
                url: 'Forms2ATV6.php',
                data: {
                    user: user,
                    product: product,
                    av: av,
                    coments: coments,
                    imagem: imagem,
                },
                success: function(response){
                    
                    $('#resultado').html(''+ response);
                   
                },
                error: function(xhr, status, error){
                    $('#resultado').html('Erro: ' + error);
              
                }

            });
        });
    });
</script>
</body>
</html>