<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Formulário de Contato</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1>Formulário de Contato</h1>
    <form  id='formulario-Contato'action="Forms2ATV4.php" method="post">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="Assunto">Assunto:</label>
        <input type="text" id="assunto" name="assunto" required><br><br>
        
        <label for="Mensagem">Mensagem:</label>
        <input type="text" id="mensagem" name="mensagem" required><br><br>

        <input type="submit" value="Enviar">
    </form>

    <div id="resultado"></div>

<script>
    $(document).ready(function() {
        $('#formulario-Contato').submit(function(event){
            event.preventDefault();

            var nome = $('#nome').val();
            var email = $('#email').val();
            var assunto = $('#email').val();
            var mensagem = $('#email').val();

            $.ajax({
                type: 'POST',
                url: 'Forms2ATV4.php',
                data: {
                    nome: nome,
                    email: email,
                    assunto: assunto,
                    mensagem: mensagem,
                },
                success: function(response){
                    
                    $('#resultado').html(''+ response);
                   
                },
                error: function(xhr, status, error){
                    $('#resultado').html('Erro: ' + error);
              
                }

            });
        });
    });
</script>
</body>
</html>