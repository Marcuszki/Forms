<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Calculadora</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1>Calculadora</h1>
    <form id='formulario-Calculadora' action="Forms2ATV5.php" method="POST">
            <label for="Numero">Digite um Numero:</label>
            <input type="number"  id="numero" value="" name="numero">
            <br>
            <label for="Numero2"> Digite outro Numero:</label>
            <input type="number"  id="numero2" value="" name="numero2">
            <br>
            <label for="Operação">Selecione sua operação:</label>
            <select id="op" name="op" required>
                <option value="">Selecione...</option>
                <option value="+">+</option>
                <option value="-">-</option>
                <option value="x">x</option>
                <option value="/">/</option>
            </select>
            <br><br>
            <button type="submit">Enviar</button>
        </form>
        <div id="resultado"></div>
        
    <script>
    $(document).ready(function() {
        $('#formulario-Calculadora').submit(function(event){
            event.preventDefault();

            var numero = $('#numero').val();
            var numero2 = $('#numero2').val();
            var op = $('#op').val();

            $.ajax({
                type: 'POST',
                url: 'Forms2ATV5.php',
                data: {
                    numero: numero,
                    numero2: numero2,
                    op: op,

                },
                success: function(response){
                    
                    $('#resultado').html(''+ response);
                   
                },
                error: function(xhr, status, error){
                    $('#resultado').html('Erro: ' + error);
              
                }

            });
        });
    });
</script>    
</body>
</html>
