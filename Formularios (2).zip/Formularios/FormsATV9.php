<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Quiz Online</title>
</head>
<body>
    <h1>Quiz Online</h1>
    <form action="Forms2ATV9.php" method="POST">
           
            <label for="Quiz">Qual o nome do protagonista do ONE PIECE ?</label>
            <select id="quiz" name="quiz[0]" required>
                <option value="">Selecione sua resposta ...</option>
                <option value="Luffy">Luffy</option>
                <option value="Zoro">Zoro</option>
                <option value="GOKU">GOKU</option>
                <option value="Renato cariani ">Renato cariani</option>
            </select>
            
            <br>
            <br>

            <label for="Quiz">Qual o nome do protagonista de Dragon Ball Z ?</label>
            <select id="quiz" name="quiz[1]" required>
                <option value="">Selecione sua resposta ...</option>
                <option value="Luffy">Luffy</option>
                <option value="Zoro">Zoro</option>
                <option value="GOKU">GOKU</option>
                <option value="Renato cariani ">Renato cariani</option>
            </select>
            
            <br>
            <br>

            <label for="Quiz">Quantas esferas existem em DBZ ?</label>
            <select id="quiz" name="quiz[2]" required>
                <option value="">Selecione sua resposta ...</option>
                <option value="7">7</option>
                <option value="2">2</option>
                <option value="1">1</option>
                <option value="9">9</option>
            </select>
          
            <br>
            <br>


            <label for="Quiz">Qual carro e da marca mitsubishi ?</label>
            <select id="quiz" name="quiz[3]" required>
                <option value="">Selecione sua resposta ...</option>
                <option value="Corolla">Corolla</option>
                <option value="Lancer">Lancer</option>
                <option value="Civic">Civic</option>
                <option value="T-CROS ">T-CROS</option>
            </select>
           
            <br>
            <br>


            <label for="Quiz">Qual time e o maior de minas ?</label>
            <select id="quiz" name="quiz[4]" required>
                <option value="">Selecione sua resposta ...</option>
                <option value="Patetico-MG">Patetico-MG</option>
                <option value="America-MG">America-MG</option>
                <option value="Cruzeiro">Cruzeiro</option>
                <option value="Ipatinga ">Ipatinga</option>
            </select>

            <br>
            <button type="submit">Enviar</button>
           
            <br>
            <br>
            
        </form>
</body>
</html>