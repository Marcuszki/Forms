<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>Pesquisa com Método GET</title>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    </head>
    <body>
        <h1>Pesquisa com Método GET</h1>
        <form id='formulario-Pesquisa' action="Forms2ATV3.php" method="GET">
        <label for="termo">Termo de Pesquisa:</label>
        <input type="text" id="termo" name="termo" required><br><br>
        <button type="submit" value="Pesquisar"> Procurar </button>
        </form>
<div id="resultado"></div>

<script>
    $(document).ready(function() {
        $('#formulario-Pesquisa').submit(function(event){
            event.preventDefault();

            var termo = $('#termo').val();
           

            $.ajax({
                type: 'GET',
                url: 'Forms2ATV3.php',
                data: {
                    termo: termo,
                },
                success: function(response){
                    
                    $('#resultado').html(''+ response);
                   
                },
                error: function(xhr, status, error){
                    $('#resultado').html('Erro: ' + error);
              
                }

            });
        });
    });
</script>
    </body>
</html>