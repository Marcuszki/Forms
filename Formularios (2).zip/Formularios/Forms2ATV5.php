<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numero = htmlspecialchars($_POST['numero']);
    $numero2 = htmlspecialchars($_POST['numero2']);
    $op = htmlspecialchars($_POST['op']);
    
    switch($op){
        case "+";
                $result = $numero + $numero2;
                echo"O resultado da soma de $numero + $numero2 = $result";
                break;
    
        case "-";
                $result = $numero - $numero2;
                echo"O resultado da subtração de $numero - $numero2 = $result";
                break;

        case "x";
                $result = $numero * $numero2;
                echo"O resultado da multiplicação de $numero x $numero2 = $result";
                break;

        case "/";
                if($numero !=0 && $numero2 !=0){
                    $result = $numero / $numero2;
                echo"O resultado da divisão de $numero / $numero2 = $result";
                }else{
                        echo "Não é possível dividir por zero.";
                }
                      
                break;
}
} else {
    echo "<h1>syntax error</h1>";
    echo "<p>Por favor, envie o formulário corretamente.</p>";
}
?>