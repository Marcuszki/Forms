<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title> Inscrição em Newsletter</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1> Inscrição em Newsletter</h1>
    <form id="formulario" action="Forms2ATV8.php" method="POST" >
            <label for="Usuario">Digite seu E-mail :</label>
            <input type="text" id="email" name="email" placeholder="Digite seu E-mail"> <br>
            <br>
          
            <button type="submit">Enviar</button>
        </form>
        <div id="resultado"></div>

<script>
    $(document).ready(function() {
        $('#formulario').submit(function(event){
            event.preventDefault();

       
            var email = $('#email').val();

            $.ajax({
                type: 'POST',
                url: 'Forms2ATV8.php',
                data: {
                    email: email,
                },
                success: function(response){
                    
                    $('#resultado').html(''+ response);
                   
                },
                error: function(xhr, status, error){
                    $('#resultado').html('Erro: ' + error);
              
                }

            });
        });
    });
</script>
</body>
</html>